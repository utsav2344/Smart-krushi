import mongoose from "mongoose";

const custSchema = new mongoose.Schema({
    cname: String,
    cnum: String,
    csmg: String
});

export const Cust = mongoose.model("Cust", custSchema);
    