import mongoose from "mongoose";

const buydSchema = new mongoose.Schema({
    iname: String,
    prise: String,
    ename: String,
    enum: String,
    eadress: String,
    ecity: String,
    epincod: String,
    equan: String
});

export const Buyd = mongoose.model('Buyd', buydSchema);
